package com.example.navegacion.ui.model

import java.io.Serializable

class User (var correo: String, var pass: String): Serializable {
}